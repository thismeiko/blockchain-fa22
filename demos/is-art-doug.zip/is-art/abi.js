// change this each time you deploy a new contract
var contractAddress = 

// paste contract ABI here
var contractABI = 